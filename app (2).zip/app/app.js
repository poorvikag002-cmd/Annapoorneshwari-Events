const $ = (s, root=document) => root.querySelector(s);
const modal = $('#authModal');
let authMode = 'signin';
$('#year').textContent = new Date().getFullYear();
const introScreen = $('#introScreen');
setTimeout(() => {
  introScreen.remove();
  document.body.classList.remove('intro-active');
}, 2000);

function readProfile(){ try{return JSON.parse(localStorage.getItem('annaProfile')||'null')}catch{return null} }
function setStatus(node,message,type='success'){node.textContent=message;node.className=`status ${type}`}
function openAuth(){modal.classList.add('open');modal.setAttribute('aria-hidden','false');$('#authStatus').textContent='';$('#authForm').elements.name.value=readProfile()?.name||'';$('#authForm').elements.email.value=readProfile()?.email||'';$('#authForm').elements.phone.value=readProfile()?.phone||''}
function closeAuth(){modal.classList.remove('open');modal.setAttribute('aria-hidden','true')}
$('#signInOpen').addEventListener('click',openAuth);
modal.querySelectorAll('[data-close]').forEach(el=>el.addEventListener('click',closeAuth));
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeAuth()});
document.querySelectorAll('[data-mode]').forEach(button=>button.addEventListener('click',()=>{authMode=button.dataset.mode;document.querySelectorAll('[data-mode]').forEach(b=>b.classList.toggle('active',b===button));$('#authSubmit').innerHTML=`${authMode==='signin'?'Sign in':'Create account'} <span>↗</span>`;$('#authTitle').textContent=authMode==='signin'?'A familiar face?':'Let’s get acquainted';$('#authIntro').textContent=authMode==='signin'?'Sign in or create an account to keep your event details handy.':'Create a local profile to make your event enquiry easier.';$('#authStatus').textContent=''}));
$('#authForm').addEventListener('submit',e=>{e.preventDefault();const data=Object.fromEntries(new FormData(e.currentTarget));localStorage.setItem('annaProfile',JSON.stringify(data));setStatus($('#authStatus'),`You’re ${authMode==='signin'?'signed in':'all set'}, ${data.name.split(' ')[0]}! Your profile is saved on this device.`);$('#signInOpen').textContent=data.name.split(' ')[0];setTimeout(closeAuth,1500)});
$('.menu-toggle').addEventListener('click',e=>{const open=$('.nav').classList.toggle('open');e.currentTarget.setAttribute('aria-expanded',open)});
document.querySelectorAll('.nav a').forEach(a=>a.addEventListener('click',()=>{$('.nav').classList.remove('open');$('.menu-toggle').setAttribute('aria-expanded','false')}));
document.querySelectorAll('[data-service]').forEach(a=>a.addEventListener('click',()=>{const select=$('[name="service"]');for(const option of select.options)if(option.text===a.dataset.service)select.value=option.value||option.text}));
const date=$('[name="date"]');date.min=new Date().toISOString().slice(0,10);
$('#bookingForm').addEventListener('submit',e=>{e.preventDefault();const data=Object.fromEntries(new FormData(e.currentTarget));const bookings=JSON.parse(localStorage.getItem('annaBookings')||'[]');data.createdAt=new Date().toISOString();bookings.push(data);localStorage.setItem('annaBookings',JSON.stringify(bookings));const message=`Hello Annapoorneshwari Events! I'd like to enquire about ${data.service}.%0AName: ${encodeURIComponent(data.name)}%0APhone: ${encodeURIComponent(data.phone)}${data.email?`%0AEmail: ${encodeURIComponent(data.email)}`:''}${data.date?`%0ADate: ${encodeURIComponent(data.date)}`:''}${data.guests?`%0AExpected guests: ${encodeURIComponent(data.guests)}`:''}${data.message?`%0ADetails: ${encodeURIComponent(data.message)}`:''}`;setStatus($('#formStatus'),'Your enquiry is saved on this device. Opening WhatsApp so you can send it to Bharath.');setTimeout(()=>window.open(`https://wa.me/919900694658?text=${message}`,'_blank','noopener'),250);e.currentTarget.reset();date.min=new Date().toISOString().slice(0,10)});

const feedbackForm = $('#feedbackForm');
const feedbackMedia = $('#feedbackMedia');
const mediaPreview = $('#mediaPreview');
const feedbackStatus = $('#feedbackStatus');
const feedbackWhatsAppLink = $('#feedbackWhatsAppLink');
const feedbackComment = feedbackForm.elements.comment;
const feedbackCharacterCount = $('#feedbackCharacterCount');
const ratingHint = $('#ratingHint');
let mediaPreviewUrls = [];

feedbackForm.querySelectorAll('input[name="rating"]').forEach(rating => {
  rating.addEventListener('change', () => {
    const labels = {
      1: 'Poor',
      2: 'Fair',
      3: 'Good',
      4: 'Very good',
      5: 'Excellent',
    };
    ratingHint.textContent = `${rating.value} out of 5 — ${labels[rating.value]}`;
  });
});

feedbackComment.addEventListener('input', () => {
  feedbackCharacterCount.textContent = `${feedbackComment.value.length} / ${feedbackComment.maxLength}`;
});

feedbackMedia.addEventListener('change', () => {
  mediaPreviewUrls.forEach(url => URL.revokeObjectURL(url));
  mediaPreviewUrls = [];
  mediaPreview.replaceChildren();
  feedbackWhatsAppLink.hidden = true;
  feedbackMedia.setCustomValidity('');

  const files = Array.from(feedbackMedia.files);
  const invalidFiles = files.some(file =>
    !/^(image|video|audio)\//.test(file.type) || file.size > 25 * 1024 * 1024
  );
  if (files.length > 5 || invalidFiles) {
    feedbackMedia.setCustomValidity('Choose up to 5 image, video, or audio files, each no larger than 25 MB.');
    setStatus(feedbackStatus, 'Choose up to 5 image, video, or audio files, each no larger than 25 MB.', 'error');
    feedbackMedia.value = '';
    return;
  }

  feedbackStatus.textContent = '';
  for (const file of files) {
    const url = URL.createObjectURL(file);
    mediaPreviewUrls.push(url);
    const figure = document.createElement('figure');
    let preview;
    if (file.type.startsWith('image/')) {
      preview = document.createElement('img');
      preview.alt = `Preview of ${file.name}`;
    } else {
      preview = document.createElement(file.type.startsWith('video/') ? 'video' : 'audio');
      preview.controls = true;
      preview.preload = 'metadata';
    }
    preview.src = url;
    const caption = document.createElement('figcaption');
    caption.textContent = `${file.name} (${(file.size / (1024 * 1024)).toFixed(1)} MB)`;
    figure.append(preview, caption);
    mediaPreview.append(figure);
  }
});

feedbackForm.addEventListener('submit', e => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(feedbackForm));
  const files = Array.from(feedbackMedia.files);
  const mediaList = files.length
    ? `\nSelected media (attach these files in WhatsApp): ${files.map(file => file.name).join(', ')}`
    : '\nNo media attached.';
  const message = [
    'Hello Annapoorneshwari Events! I would like to share feedback.',
    `Name: ${data.name}`,
    `Role: ${data.role}`,
    `Rating: ${data.rating}/5`,
    `Feedback: ${data.comment}`,
  ].join('\n') + mediaList;

  feedbackWhatsAppLink.href = `https://wa.me/919900694658?text=${encodeURIComponent(message)}`;
  feedbackWhatsAppLink.hidden = false;
  setStatus(feedbackStatus, 'Your feedback is ready. Open WhatsApp below, review the message, and attach your selected media there.');
});
